﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project.Controllers.User
{
     
    class AccountController
    {
        ACCOUNT a;
        USER u;
        DBLINKDataContext Database = new DBLINKDataContext();
        public AccountController()
        {

        }
        public bool Insert(string accNo,string accType,float balance,DateTime createdDate,DateTime UpdatedDate,int uid)
        {
            try
            {
                //u = Database.USERs.SingleOrDefault(obj => obj.username == uname);
                //bool result = true;
                a = new ACCOUNT();
                a.account_number = accNo;
                a.account_type = accType;
                a.total_balance = balance;
                a.created_date = createdDate;
                a.updated_date = UpdatedDate;
                a.user_id = uid;
                Database.ACCOUNTs.InsertOnSubmit(a);
                Database.SubmitChanges();
                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString()); 
                return false;
            }
            
        } 
    }
}

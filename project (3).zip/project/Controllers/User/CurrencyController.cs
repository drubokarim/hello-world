﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project.Controllers.User
{
    class CurrencyController
    {
        DBLINKDataContext Database = new DBLINKDataContext();
        USER user;//
        CURRENCY c;//ekhane use kora jabe? remember Controller
        // shob kisu use korte parba....but interface e nah
        public string username { get; private set; }
        public CurrencyController()
        {
            this.user = Database.USERs.SingleOrDefault(obj => obj.Id == Properties.Settings.Default.CurrentUserID);
            this.username = user.username;
        }
        public Object Load_Currencies()
        {
            object ob = Database.CURRENCies;
            return ob;
        }
        public bool Update(string cname,String ccode,int rate,int id)
        {
            try
            {
                // eikhane tumi checking korteso ccode er shate
                // why? is ccode unique? or primary? 
                // shono tahole manush ccode change korte parbe?
                // nnow thik ase..er age id er kono value e silo nah..
                // now interface theke arekta parameter pass korba tomar idx.
                // select row korlei oi idx er shate check kore update korbe
                CURRENCY c = Database.CURRENCies.SingleOrDefault(obj => obj.id == id);
                if (c != null)
                {
                    c.currency_name = cname;
                    c.currency_code = ccode;
                    c.rate = rate;

                    // ekhon jodi submitchanges hoi tahole true...
                    // thiki to ase...
                    Database.SubmitChanges();
                    return true; // <<?
                }
                else
                    return false;
                
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }
        public bool ADD(string cname, String ccode, int rate)
        {
            try
            {
                c = new CURRENCY();
                c.currency_name = cname;
                c.currency_code=ccode;
                c.rate = rate;
                Database.CURRENCies.InsertOnSubmit(c);
                Database.SubmitChanges();
                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }  
            
        }//o
        public bool Delete(int idx) // accha taile idx tar value kotha theke paiteso.ektu dekhao
        {
            c = Database.CURRENCies.SingleOrDefault(obj => obj.id ==idx);
            if(c!=null)
            {
                Database.CURRENCies.DeleteOnSubmit(c);
                Database.SubmitChanges();
                return true;
            }
            else
            {
                
                return false;
            }
            
        }




        // ei function ta dekho ...kivabe insert korsi..
        // always use parameter to pass data
        // taile tomar CURRENCY interface e use korte hobe nah
        /*public bool Step4(string bloodgrp, bool diab, string sugarl, bool pressure, string avgpressure)
        {
            bool result = false;
            try
            {
                newUser.PBloodGrp = bloodgrp;
                newUser.PDiabetes = diab;
                newUser.PBloodSugar = sugarl;
                newUser.PPressure = pressure;
                newUser.PAvgPressure = avgpressure;

                // update er khetre
                Database.SubmitChanges();
                // then result = true; and it will return true..
                result = true;//ekhane false hobe na?
                // nah update er khetre eivabe korba tomar code e dekhai
                // dei
                if (insert())
                {

                    result = true;
                    MessageBox.Show("Thanks for registerting in our system !");
                    new Login().Show();
                    this.frm.Hide();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Exception caught.", e);
                result = false;
            }

            return result;
        }*/
    }
}

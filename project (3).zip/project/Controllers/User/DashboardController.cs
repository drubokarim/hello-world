﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace project.Controllers.User
{
    class DashboardController
    {
        DBLINKDataContext Database = new DBLINKDataContext();
        USER user;//eikhane j db model use kora hoise na? hm?
        // 
        public string username { get; private set; }

        public DashboardController()
        {

            this.user = Database.USERs.SingleOrDefault(obj => obj.Id == Properties.Settings.Default.CurrentUserID);
            this.username = user.username;
        }

        public bool Logout()
        {
            try
            {
                if (this.user != null)
                {
                    this.user.status = false;
                    Properties.Settings.Default.CurrentUserID = 0;
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                return false;
            }
        }
    }
}

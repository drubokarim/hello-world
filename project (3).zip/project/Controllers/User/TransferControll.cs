﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project.Controllers.User
{
    class TransferControll
    {
        ACCOUNT dbAcc,crAcc,a;
        TRANSACTION trHistory, trHistory1;

        DBLINKDataContext Database = new DBLINKDataContext();
        public TransferControll()
        {
           //a = new ACCOUNT();
            trHistory = new TRANSACTION();
            trHistory1 = new TRANSACTION();
        }
        public void load_from(ref ComboBox cm)
        {

            var data = from acc in Database.ACCOUNTs
                       where acc.account_type.Equals("Debit Account") && acc.user_id.Equals(Properties.Settings.Default.CurrentUserID)
                       select acc ;

            cm.DataSource = data;
            cm.DisplayMember = "account_number";
            cm.ValueMember = "Id";
            

            
        }
        public bool proceedUserToUser(string tr_code, String from, String user,string accNo, float amount, DateTime happnddatetime, bool status, string description)
        {
            try
            {
                //a
                USER u = Database.USERs.SingleOrDefault(ob => ob.username==user);
               a = Database.ACCOUNTs.SingleOrDefault(ob=> ob.account_number==accNo && ob.user_id==u.Id ) ;
                
                //a = Database.ACCOUNTs.SingleOrDefault(ob => ob.account_number == accNo; ob.account_type="");
                dbAcc = Database.ACCOUNTs.SingleOrDefault(obj => obj.account_number == from);
                if (dbAcc.total_balance > amount)
                {
                    dbAcc.total_balance -= amount;
                    Database.SubmitChanges();
                    //crAcc = Database.ACCOUNTs.SingleOrDefault(obj => obj.account_number == to);
                    a.total_balance += amount;
                    Database.SubmitChanges();
                    trHistory1.tr_code = tr_code;
                    trHistory1.from = from;
                    trHistory1.to = a.account_number;
                    trHistory1.amount = amount;
                    trHistory1.happened_date_time = happnddatetime;
                    trHistory1.status = status;
                    trHistory1.description = description;
                    Database.TRANSACTIONs.InsertOnSubmit(trHistory1);
                    Database.SubmitChanges();
                    return true;
                }
                else
                {
                    MessageBox.Show("You do not have that much money to transfer");
                    return false;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }
        public void load_To(ref ComboBox cm)
        {

            var data = from acc in Database.ACCOUNTs
                       where acc.account_type.Equals("Credit Account") && acc.user_id.Equals(Properties.Settings.Default.CurrentUserID)
                       select acc;
            
            cm.DataSource = data;
            cm.DisplayMember = "account_number";
            cm.ValueMember = "Id";
        }
         
        public bool ProceedAccTOAcc(string tr_code,String from,String to,float amount,DateTime happnddatetime,bool status,string description)
        {
            try
            {
                dbAcc = Database.ACCOUNTs.SingleOrDefault(obj => obj.account_number == from);
                if(dbAcc.total_balance>amount)
                {
                    dbAcc.total_balance -= amount;
                    Database.SubmitChanges();
                    crAcc = Database.ACCOUNTs.SingleOrDefault(obj => obj.account_number == to);
                    crAcc.total_balance += amount;
                    Database.SubmitChanges();
                    trHistory.tr_code = tr_code;
                    trHistory.from = from;
                    trHistory.to = to;
                    trHistory.amount = amount;
                    trHistory.happened_date_time = happnddatetime;
                    trHistory.status = status;
                    trHistory.description = description;
                    Database.TRANSACTIONs.InsertOnSubmit(trHistory);
                    Database.SubmitChanges();
                    return true;
                }
                else
                {
                    MessageBox.Show("You do not have that much money to transfer");
                    return false;
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

    }

}

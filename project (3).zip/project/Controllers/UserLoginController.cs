﻿using System;
using System.Linq;
using System.Security.Cryptography;

namespace project.Controllers
{
    class UserLoginController
    {
        DBLINKDataContext Database = new DBLINKDataContext();

        public bool Admin { get; private set; }

        public UserLoginController()
        {
            this.Admin = false;
        }

        public bool Login(string Username, string Password)
        {
            bool result = false;

            USER user = Database.USERs.SingleOrDefault(obj => obj.username == Username);
            if (user != null)
            {
                if (DecryptPassword(user.password, Password))
                {
                    if (checkType(user))
                    {
                        if (updateStatus(user))
                        {
                            // Session
                            Properties.Settings.Default.CurrentUserID = user.Id;
                            // -------------------------------------------------------

                            result = true;
                        }
                    }
                }
                else {
                    result = false;
                }
            }
            else {
                result = false;
            }

            return result;
        }

        private bool checkType(USER user)
        {
            if (user.usertype == true)
            {
                this.Admin = true;
            }
            else
            {
                this.Admin = false;
            }
            return true;
        }

        private bool updateStatus(USER user)
        {
            try
            {
                user.status = true;

                Database.SubmitChanges();

                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("{0}", e);
                return false;
            }
        }

        private bool DecryptPassword(string DBPassword, string UPassword)
        {
            bool result = false;

            /* Extract the bytes */
            byte[] hashBytes = Convert.FromBase64String(DBPassword);
            /* Get the salt */
            byte[] salt = new byte[16];
            Array.Copy(hashBytes, 0, salt, 0, 16);

            /* Compute the hash on the password the user entered */
            var pbkdf2 = new Rfc2898DeriveBytes(UPassword, salt, 10000);
            byte[] hash = pbkdf2.GetBytes(20);

            /* Compare the results */
            for (int i = 0; i < 20; i++)
            {
                if (hashBytes[i + 16] != hash[i])
                {
                    result = false;
                    throw new UnauthorizedAccessException();
                }
                else
                {
                    result = true;
                }
            }

            return result;
        }
    }
}

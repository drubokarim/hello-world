﻿using System;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace project.Controllers
{
    class UserRegistrationController
    {
        DBLINKDataContext Database = new DBLINKDataContext();
        USER user = new USER();
        USERINFO userinfo = new USERINFO();



        public UserRegistrationController()
        {

        }

        public bool Register(string Username, string Password, string Email, int SecId, string SecAnswer, string FirstName, string LastName, DateTimePicker Dob, string Phone, string Address)
        {
            bool result = false;

            try
            {
                user.username = Username;
                user.password = EncryptPassword(Password);
                user.email = Email;
                user.securityid = SecId;
                user.securityanswer = SecAnswer;
                user.created_at = DateTime.Now;

                Database.USERs.InsertOnSubmit(user);
                Database.SubmitChanges();

                userinfo.userid = user.Id;
                userinfo.firstname = FirstName;
                userinfo.lastname = LastName;
                userinfo.dob = Dob.Value.Date;
                userinfo.phone = Phone;
                userinfo.address = Address;

                Database.USERINFOs.InsertOnSubmit(userinfo);
                Database.SubmitChanges();

                result = true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                result = false;
            }


            return result;
        }

        private string EncryptPassword(string Password)
        {
            // Creating the salt value with a cryptographic PRNG
            byte[] salt;
            new RNGCryptoServiceProvider().GetBytes(salt = new byte[16]);

            // Create the Rfc2898DeriveBytes and get the hash value
            var pbkdf2 = new Rfc2898DeriveBytes(Password, salt, 10000);
            byte[] hash = pbkdf2.GetBytes(20);

            // Combine the salt and password bytes for later use
            byte[] hashBytes = new byte[36];
            Array.Copy(salt, 0, hashBytes, 0, 16);
            Array.Copy(hash, 0, hashBytes, 16, 20);

            // Turn the combined salt+hash into a string for storage
            string savedPasswordHash = Convert.ToBase64String(hashBytes);

            return savedPasswordHash;
        }

        public object getQuestions()
        {
            return Database.QUESTIONs;
        }
    }
}

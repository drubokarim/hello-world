﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using project.Controllers.User;
namespace project.Forms.User
{
    // Ar please again boltesi naming thik koira koro kaj..
    // naile onno team member kissu bujbe nah and tomar
    // file kajeo lagaite parbe nah...
    public partial class frmCurrencies : Form
    {
        int idx;
        CurrencyController Controller = new CurrencyController();
        //CURRENCY c; // you can't use directly CURRENCY database model
        // from interface; eitar solution ase....dekhaitesi..age boli
        // ki ki vul gese
        public frmCurrencies()
        {
            InitializeComponent();
            idx = 0;
            // datagridview1 < keno? ekta understandable name diba shob
            // controls er interface er
            loadCurrencies();
        }
        private void loadCurrencies()
        {
            this.Currencies.DataSource = null;
            

            this.Currencies.DataSource = Controller.Load_Currencies();
            
        }
        private void frmCurrencies_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // eikhane je idx pass koraiteso...idx er value koi?
            //interface theke ashbe
            // kamne ashbe shei code koi?
            if(Controller.Delete(idx))
            {
                MessageBox.Show("Successfully Deleted");
                this.Currencies.DataSource=Controller.Load_Currencies();
            }
            else
                MessageBox.Show("Deletion Unsuccessful");
        }
        private void Delete_Click(object sender, EventArgs e)
        {
            // eikhane je idx pass koraiteso...idx er value koi?
            //interface theke ashbe
            // kamne ashbe shei code koi?
            if (Controller.Delete(idx))
            {
                MessageBox.Show("Successfully Deleted");
                loadCurrencies();
            }
            else
                MessageBox.Show("Deletion Unsuccessful");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        
        private void Currencies_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // ok so here is again a bug...// keu jodi row select 
            // na kore then null reference ashbe .....
            // + ei approch ta thik ase but null ref asha bondo korte
            // parba?
            // jodi database 0 id er row na pai? then ?delete hobe na
            // error dibe nah? lets see
            // jeta dekhla eita amar bug :p ...fix korsi update e..
            // ok so database painai boila messagebox show kortese
            // eita thik ase tahole..done...next update e
            int index = e.RowIndex;
            DataGridViewRow selectedRow = Currencies.Rows[index];
            idx = int.Parse(selectedRow.Cells[0].Value.ToString());
            MessageBox.Show(idx.ToString());
            Currency_name.Text= selectedRow.Cells[2].Value.ToString();
            Currency_code.Text = selectedRow.Cells[1].Value.ToString();
            Rate.Text = selectedRow.Cells[3].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if(Controller.ADD(Currency_name.Text, Currency_code.Text, int.Parse(Rate.Text)))
            {
                MessageBox.Show("Successfully inserted");
                this.Currencies.DataSource=Controller.Load_Currencies();
            }
            else
                MessageBox.Show("insertion unsuccessful");
            //if(Controller.)
        }

        private void ADD_Click(object sender, EventArgs e)
        {

            if (Controller.ADD(Currency_name.Text, Currency_code.Text, int.Parse(Rate.Text)))
            {
                MessageBox.Show("Successfully inserted");
                // make a load funnction ...this jokhon diteso 
                // he already knows what inside it...if you make a new
                // it will update
                loadCurrencies();
            }
            else
                MessageBox.Show("insertion unsuccessful");
            //if(Controller.)
        }

        // ei dekho name diso Update...naile khuijai paitam na :p
        private void Update_Click(object sender, EventArgs e)
        {
            // update e CURRENCY eivabe use kora jabe nah..tomake
            // ami function ditesi wait
           
            // eikhane tumi just check korba true na false...
            // true hoile success message....thats it...
            // ar update e jokhon select row koro...tokhon 
            // textbox gula fillup kore dao jeno user old values
            // dekhte pa
            //re ...tumi eikhane just id select korteso../

            // bujhso? hm
            //bool result = true;
            if(Controller.Update(Currency_name.Text,Currency_code.Text, int.Parse(Rate.Text),idx))
            {
                //resul
                MessageBox.Show("Successfully updated");
                loadCurrencies();
            }
            else
                MessageBox.Show("update unsuccessful");
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

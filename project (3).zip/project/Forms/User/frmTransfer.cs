﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using project.Controllers.User;
namespace project.Forms.User
{
    public partial class frmTransfer : Form
    {
        TransferControll Controller = new TransferControll();
        public frmTransfer()
        {
            InitializeComponent();
            load_accounts();
            
        }
        private void load_accounts()
        {
            Controller.load_from(ref From);
            Controller.load_To(ref To);
            Controller.load_from(ref From1);
        }
        private void Proceed_Click(object sender, EventArgs e)
        {
            if(Controller.proceedUserToUser(DateTime.Now.ToString(),From1.Text,username.Text,AccNo.Text,float.Parse(Amount1.Text),DateTime.Now,true,Description1.Text))
            {
                MessageBox.Show("Transfer Successful");
                
            }
            else
                MessageBox.Show("Transfer Unsuccessful");
        }

        private void Proceed0_Click(object sender, EventArgs e)
        {
            //string tr_code,String from,String to,float amount,DateTime happnddatetime,bool status,string description
            if(Controller.ProceedAccTOAcc(DateTime.Now.ToString(),From.Text,To.Text,float.Parse(Amount.Text),DateTime.Now,true,Description.Text))
            {
                MessageBox.Show("Transfer Successful");
            }
            else
                MessageBox.Show("Transfer Unsuccessful");
        }
    }
}

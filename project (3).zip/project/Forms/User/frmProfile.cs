﻿using System.Windows.Forms;

namespace project.Forms.User
{
    public partial class frmProfile : Form
    {
        public frmProfile()
        {
            InitializeComponent();
        }
    }
}

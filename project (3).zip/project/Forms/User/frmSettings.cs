﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project.Forms.User
{
    public partial class frmSettings : Form
    {
        frmCurrencies newCurrencyForm =new frmCurrencies();
        public frmSettings()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            newCurrencyForm = new frmCurrencies();
            newCurrencyForm.Show();
            //CloseAllFormsExcept(newCurrencyForm);
            //newSettingsForm.MdiParent = this;
            //newSettingsForm.Show();
        }

    }
}

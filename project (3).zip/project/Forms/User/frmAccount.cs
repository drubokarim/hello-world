﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// Ekta interface banaite hoi je :( // frmAddAccount.cs
// eki design follow koiro..just copy paste maire form ta banao
//ok ami ektu 30 miniute pore ashtesi
// ok no problem lol ...asho....amake knock koiro aisha ...
//ok


namespace project.Forms.User
{
    public partial class frmAccount : Form
    {
        public frmAccount()
        {
            InitializeComponent();
        }

        private void btnAddAccount_Click(object sender, EventArgs e)
        {
            new frmAddAccount().Show();

        }
    }
}

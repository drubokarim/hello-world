﻿using project.Controllers.User;
using System;
using System.Windows.Forms;

namespace project.Forms.User
{
    public partial class frmDashboard : Form
    {
        DashboardController Controller = new DashboardController();



        frmAccount newAccountForm = new frmAccount();
        frmTransfer newTransferForm = new frmTransfer();
        frmStatements newStatementsForm = new frmStatements();
        frmSettings newSettingsForm = new frmSettings();

        public frmDashboard(bool LoggedInSuccess)
        {
            InitializeComponent();

            // Session Check
            if (!LoggedInSuccess && Properties.Settings.Default.CurrentUserID != 0)
            {
                new Login().Show();
                Close();
            }
            else
            {
                lblUsername.Text = Controller.username;
            }
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {
            Left = Top = 0;
            Width = Screen.PrimaryScreen.WorkingArea.Width;
            Height = Screen.PrimaryScreen.WorkingArea.Height;
        }

        private void btnSubMenu_Click(object sender, EventArgs e)
        {
            if (menuSub.Visible == true)
            {
                menuSub.Hide();
            }
            else
            {
                menuSub.Show(new System.Drawing.Point(1888, 70));
            }
        }

        private void sbmenuLogout_Click(object sender, EventArgs e)
        {
            if (Controller.Logout())
            {
                MessageBox.Show("Successfully Logged Out !");
                Close();
                new Login().Show();
            }
            else
            {
                MessageBox.Show("Error Occurred !");
            }
        }

        private void sbmenuLogout_OnHover(object sender, EventArgs e)
        {
            sbmenuLogout.BackColor = System.Drawing.Color.Red;
        }
        private void sbmenuLogout_MouseEnter(object sender, EventArgs e)
        {
            sbmenuLogout.BackColor = System.Drawing.Color.Red;
        }
        private void sbmenuLogout_MouseLeave(object sender, EventArgs e)
        {
            sbmenuLogout.BackColor = System.Drawing.Color.Gray;
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            new frmSettings().Show();
        }

        private void btnSettings_Click_1(object sender, EventArgs e)
        {
            newSettingsForm = new frmSettings();
            CloseAllFormsExcept(newSettingsForm);
            newSettingsForm.MdiParent = this;
            newSettingsForm.Show();
        }

        private void btnAccounts_Click(object sender, EventArgs e)
        {
            newAccountForm = new frmAccount();
            CloseAllFormsExcept(newAccountForm);
            newAccountForm.MdiParent = this;
            newAccountForm.Show();
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            newTransferForm = new frmTransfer();
            CloseAllFormsExcept(newTransferForm);
            newTransferForm.MdiParent = this;
            newTransferForm.Show();
        }

        private void btnStatements_Click(object sender, EventArgs e)
        {
            newStatementsForm = new frmStatements();
            CloseAllFormsExcept(newStatementsForm);
            newStatementsForm.MdiParent = this;
            newStatementsForm.Show();
        }




        private void CloseAllFormsExcept(Form thisform)
        {

            if (thisform == newAccountForm)
            {
                //newAccountForm.Close();
                newTransferForm.Close();
                newStatementsForm.Close();
                newSettingsForm.Close();
            }
            if (thisform == newTransferForm)
            {
                newAccountForm.Close();
                //newTransferForm.Close();
                newStatementsForm.Close();
                newSettingsForm.Close();
            }
            if (thisform == newStatementsForm)
            {
                newAccountForm.Close();
                newTransferForm.Close();
                //newStatementsForm.Close();
                newSettingsForm.Close();
            }
            if (thisform == newSettingsForm)
            {
                newAccountForm.Close();
                newTransferForm.Close();
                newStatementsForm.Close();
                //newSettingsForm.Close();
            }


        }

        private void frmDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Controller.Logout())
            {
                MessageBox.Show("Successfully Logged Out !");
                Close();
                new Login().Show();
            }
            else
            {
                MessageBox.Show("Error Occurred !");
            }
        }
    }
}

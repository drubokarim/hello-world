﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using project.Controllers.User;
namespace project.Forms.User
{
    public partial class frmAddAccount : Form
    {
        AccountController controller = new AccountController();
        public frmAddAccount()
        {
            InitializeComponent();
        }

        private void frmAddAccount_Load(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if(controller.Insert(AccNumber.Text,AccType.Text,float.Parse(Initial_Balance.Text), DateTime.Now, DateTime.Now, Properties.Settings.Default.CurrentUserID))
            {
                MessageBox.Show("Successfully Added the Account");
            }
            else
                MessageBox.Show("Account Insertion Unsuccessful");
        }
    }
}

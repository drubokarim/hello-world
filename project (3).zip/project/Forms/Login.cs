﻿using project.Controllers;
using System;
using System.Windows.Forms;



namespace project.Forms
{
    public partial class Login : Form
    {
        UserLoginController Controller = new UserLoginController();

        public Login()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            if (tbxUsername.Text != "" && tbxPassword.Text != "")
            {
                if (Controller.Login(tbxUsername.Text, tbxPassword.Text))
                {
                    MessageBox.Show("Successfully Logged In !");
                    if (Controller.Admin == true)
                    {

                    }
                    else
                    {
                        new User.frmDashboard(true).Show();
                        Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect Credentials, Please try again !");
                }
            }
            else
            {
                MessageBox.Show("Please provide full credentials !");
            }

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            new Registration().Show();
            Hide();
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project.Forms.Admin
{
    public partial class frmTramsferAdmin : Form
    {
        public frmTramsferAdmin()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmTramsferAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}

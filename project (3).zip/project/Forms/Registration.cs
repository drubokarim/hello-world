﻿using project.Controllers;
using System;
using System.Windows.Forms;

namespace project.Forms
{
    public partial class Registration : Form
    {
        UserRegistrationController Controller = new UserRegistrationController();

        String Address = "";

        public Registration()
        {
            InitializeComponent();

            cmbQuestion.DataSource = Controller.getQuestions();
            cmbQuestion.DisplayMember = "question";
            cmbQuestion.ValueMember = "Id";
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Address += tbxAddress.Text;
            this.Address += string.Join(",", tbxAddress2nd.Text);
            this.Address += string.Join(",", tbxCity.Text);
            this.Address += string.Join(",", tbxZip.Text);
            this.Address += string.Join(",", tbxCountry.Text);

            if (Controller.Register(tbxUsername.Text, tbxPassword.Text, tbxEmail.Text, int.Parse(cmbQuestion.SelectedValue.ToString()), tbxAnswer.Text,
                tbxFirstName.Text, tbxLastName.Text, dpDob, tbxPhone.Text, this.Address))
            {
                MessageBox.Show("Successfully Registered !");
                new Login().Show();
                Hide();
            }
            else
            {
                MessageBox.Show("Error Occurred !");
            }
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            new Login().Show();
            Close();
        }
    }
}
